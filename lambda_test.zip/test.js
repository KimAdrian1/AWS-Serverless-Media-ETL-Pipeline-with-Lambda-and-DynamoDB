let testArray = [
  {
    Name: "Avengers Infinity War",
    Description:
      "The Avengers and their allies must be willing to sacrifice all in an attempt to defeat the powerful Thanos before his blitz of devastation and ruin puts an end to the universe.",
    Year: 2018,
  },
  {
    Name: "Harry Potter and The Prisoner of Askaban",
    Description:
      "Harry Potter, Ron and Hermione return to Hogwarts School of Witchcraft and Wizardry for their third year of study, where they delve into the mystery surrounding an escaped prisoner who poses a dangerous threat to the young wizard.",
    Year: 2004,
  },
  {
    Name: "The Curious Case of Benjamin Button",
    Description:
      "Benjamin Button, born in 1918 with the physical state of an elderly man, ages in reverse. He experiences love and break-ups, ecstasy and sorrow, and timelessness by the time he dies in 2003 as a baby.",
    Year: 2008,
  },
  {
    Name: "The Amazing Spider-Man 2",
    Description:
      "When New York is put under siege by Oscorp, it is up to Spider-Man to save the city he swore to protect as well as his loved ones.",
    Year: 2014,
  },
];
testArray;
